import { styled } from 'linaria/react'
import { View } from '@tarojs/components'

const center = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  flexDirection: 'column',
}


// export const RightIn = styled(View)<{right: any}>`
// animation: RightIn 1s ease;

// @keyframes RightIn {
//   from {
//     transform: translatex(${ props => ((props.right + 1)  * 1000)}px);
//     opacity: 0;
//   }

//   to {
//     transform: translateY(0px);
//     opacity:1;
//   }
// }
// `
